<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/logo.png" type="">

  <title> SAFE WASH </title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">

  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />

  <!-- Custom styles for this template -->

  <link href="css/styleB.css" rel="stylesheet" />

  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />

</head>

<body class="sub_page">

  <div class="hero_area">

    <div class="hero_bg_box">
      <div class="bg_img_box">
        <img src="images/hero-bg.png" alt="">
      </div>
    </div>

    <!-- header section strats -->
    <header class="header_section">
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index.php">
            <span>
              Safe Wash
            </span>
          </a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class=""> </span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav  ">
              <li class="nav-item ">
                <a class="nav-link" href="index.php">Home </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Branch.php"> Branch</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="about.php">About </a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="service.php">Service</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Promotion.php">Promotion</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="login_form.php">Login</a>
              </li>
              <form class="form-inline">
              </form>
            </ul>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
  </div>


  <!-- service section -->
ิ<br>
  <div id="category-bar-container" class="container category-bar-con">
    <section id="home-category" class="home-category">
    <div id="category-banner" class="flex owl-carousel categories-banner owl-loaded owl-drag">
      <div class="heading_container">
        <h2>
          Wash <span>Service</span>
        </h2>
    <br>
    
    <p>Work process</p>
    <br>
    <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1032px;"><div class="owl-item active" style="width: 108.889px; margin-right: 20px;"><div id="flex-categories" class="flex-categories pizza active">
    <img id="category-image" ng-src="https://cdn.1112.com/1112/public/images/Category/pizza-v3.png" alt="พิซซ่า" class="img-responsive" src="https://cdn.1112.com/1112/public/images/Category/pizza-v3.png">
    <a id="category-slug" href="https://1112.com/pizza" class="name"><span>พิซซ่า</span></a>
    </div></div><div class="owl-item active" style="width: 108.889px; margin-right: 20px;"><div id="flex-categories" class="flex-categories special-deals">
    <img id="category-image" ng-src="https://cdn.1112.com/1112/public/images/Menu/SpecialDeals.png" alt="ดีลสุดพิเศษ" class="img-responsive" src="https://cdn.1112.com/1112/public/images/Menu/SpecialDeals.png">
    <a id="category-slug" href="https://1112.com/special-deals" class="name"><span>ดีลสุดพิเศษ</span></a>
    </div></div><div class="owl-item active" style="width: 108.889px; margin-right: 20px;"><div id="flex-categories" class="flex-categories value-set">
    <img id="category-image" ng-src="https://cdn.1112.com/1112/public/images/Menu/ValuSet.png" alt="ชุดสุดคุ้ม" class="img-responsive" src="https://cdn.1112.com/1112/public/images/Menu/ValuSet.png">
    <a id="category-slug" href="https://1112.com/value-set" class="name"><span>ชุดสุดคุ้ม</span></a>
    </div></div><div class="owl-item active" style="width: 108.889px; margin-right: 20px;"><div id="flex-categories" class="flex-categories appetizers">
    <img id="category-image" ng-src="https://cdn.1112.com/1112/public/images/Menu/card_Appetizers.png" alt="อาหารทานเล่น" class="img-responsive" src="https://cdn.1112.com/1112/public/images/Menu/card_Appetizers.png">
    <a id="category-slug" href="https://1112.com/appetizers" class="name"><span>อาหารทานเล่น</span></a>
    </div></div><div class="owl-item active" style="width: 108.889px; margin-right: 20px;"><div id="flex-categories" class="flex-categories chicken">
    <img id="category-image" ng-src="https://cdn.1112.com/1112/public/images/Menu/card_Chicken.png" alt="ไก่" class="img-responsive" src="https://cdn.1112.com/1112/public/images/Menu/card_Chicken.png">
    <a id="category-slug" href="https://1112.com/chicken" class="name"><span>ไก่</span></a>
    </div></div><div class="owl-item active" style="width: 108.889px; margin-right: 20px;"><div id="flex-categories" class="flex-categories pasta">
    <img id="category-image" ng-src="https://cdn.1112.com/1112/public/images/Menu/card_Pasta.png" alt="พาสต้า" class="img-responsive" src="https://cdn.1112.com/1112/public/images/Menu/card_Pasta.png">
    <a id="category-slug" href="https://1112.com/pasta" class="name"><span>พาสต้า</span></a>
    </div></div><div class="owl-item active" style="width: 108.889px; margin-right: 20px;"><div id="flex-categories" class="flex-categories salad">
    <img id="category-image" ng-src="https://cdn.1112.com/1112/public/images/Menu/card_Salad.png" alt="สลัดและสเต็ก" class="img-responsive" src="https://cdn.1112.com/1112/public/images/Menu/card_Salad.png">
    <a id="category-slug" href="https://1112.com/salad" class="name"><span>สลัดและสเต็ก</span></a>
    </div></div><div class="owl-item active" style="width: 108.889px; margin-right: 20px;"><div id="flex-categories" class="flex-categories drinks-and-desserts">
    <img id="category-image" ng-src="https://cdn.1112.com/1112/public/images/Menu/card_Desserts.png" alt="เครื่องดื่มและของหวาน" class="img-responsive" src="https://cdn.1112.com/1112/public/images/Menu/card_Desserts.png">
    <a id="category-slug" href="https://1112.com/drinks-and-desserts" class="name"><span>เครื่องดื่มและของหวาน</span></a>
    </div></div></div></div><div class="owl-nav disabled"><div class="owl-prev disabled"><div><i class="fa fa-chevron-left"></i></div></div><div class="owl-next disabled"><div><i class="fa fa-chevron-right"></i></div></div></div><div class="owl-dots disabled"></div></div>
    </section>
    </div>


  <!-- end service section -->
  <div id="flex-item" class="flex-item" ng-repeat="(t, topping) in toppings" topping-loaded="">
    <div id="170005" class="pizza-item" data-item-name="Aloha" data-item-id="170005" data-item-index="0">
    <div id="row" class="row">
    <div id="col" class="col-md-5">
    <div id="item-image" class="item-image">
    <img id="product-image" class="product-image" alt="Aloha" ng-src="https://cdn.1112.com/1112/public/images/products/pizza/Sep23/170005.png" src="https://cdn.1112.com/1112/public/images/products/pizza/Sep23/170005.png">
    </div>
    </div>
    <div id="col" class="col-md-7">
    <div id="item-content-container" class="item-content-container">
    <h2 id="item-name" class="item-name">อะโลฮ่า</h2>
    <p id="item-desc" class="item-desc">ไส้กรอกรมควัน, เป๊ปเปอโรนี, แฮม, สับปะรด, มอสซาเรลล่าชีส และซอสเทาซันไอส์แลนด์</p>
    </div>
    <div id="item-options" class="item-options">
    <div id="row" class="row">
    <div id="col" class="col-md-4">
    <h5 id="select-crust" class="mb10">เลือกขอบ</h5>
    <div class="select2-style select-box first-selected">
    <select id="selected-crust" style="width: 100%;" class="selectedCrust ng-pristine ng-untouched ng-valid ng-not-empty select2-hidden-accessible" data-default-crust="68" ng-model="selectedCrust[t]" ng-change="changePizzaCrust(t)" tabindex="-1" aria-hidden="true">
    <option value=""></option>
    </div>
    </div>
    <div id="col" class="col-md-4">
    <h5 id="select-dipping-sauce" class="mb10">เลือกซอส</h5>
    <div class="select2-style select-box">
    <select id="selected-default-sauce" style="width: 100%;" class="selectedDefaultSauce ng-pristine ng-untouched ng-valid ng-empty select2-hidden-accessible" data-default-size="" ng-model="selectedDippingSauce[t]" ng-disabled="topping.availableDippingSauces.length == 0" disabled="" tabindex="-1" aria-hidden="true">
    <option value="" selected="selected"></option>
    <!---->
    </select><span class="select2 select2-container select2-container--default select2-container--disabled" dir="ltr" style="width: 100%;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1" aria-labelledby="select2-selected-default-sauce-container"><span class="select2-selection__rendered" id="select2-selected-default-sauce-container"><span class="select2-selection__placeholder"></span></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
    <!----><div id="available-sauce" class="selectbox-disabled" ng-if="topping.availableDippingSauces.length == 0">ไม่มีซอส</div><!---->
    </div>
    </div>
    <div id="col" class="col-md-4">
    <h5 id="select-size-text" class="mb10">เลือกขนาด</h5>
    <div class="select2-style select-box">
    <select id="selected-size" style="width: 100%;" class="selectedSize ng-pristine ng-untouched ng-valid ng-not-empty select2-hidden-accessible" data-default-size="8" ng-model="selectedSize[t]" ng-change="changePizzaSize(t)" tabindex="-1" aria-hidden="true">
    <option value=""></option>
<option ng-repeat="size in topping.availableSizes | orderBy:'id'" ng-selected="true" class="size-item custom-option" data-alt="Medium" data-image-path="https://cdn.1112.com/1112/public/images/products/sizes/m-size.svg" value="8" selected="selected">กลาง</option>
    </select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 100%;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-selected-size-container"><span class="select2-selection__rendered" id="select2-selected-size-container" title="กลาง"><span class="pizza-widget-option-list"><img alt="Medium" src="https://cdn.1112.com/1112/public/images/products/sizes/m-size.svg"> กลาง</span></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
    </div>
    </div>
    </div>
    </div>
    <div id="add-btn" class="add-btn">
    <div id="row" class="row">
    <div id="col" class="col-md-6">
    <div id="customize-btn" class="customize-btn ng-hide" ng-show="topping.can_customize">
    <a id="customize-href" href="https://1112.com/pizza/170005?filter=all" class="customize btn btn-inline btn-default outline"><small>เลือกส่วนผสม / แบ่งครึ่งถาด</small></a>
    </div>
    </div>
    <div id="col" class="col-md-6 text-right">
    <button id="add-pza" class="btn btn-green-grid btn-inline add-to-cart" ng-click="addPizza($event.target, 'Pizza', 'G-SFE2VJ97M7')">
    <span id="price" class="left price">
    <!---->
    <span id="price-no" class="price-no" style="margin-left:10px;">159</span> ฿ </span>
    <span class="right txt">
    <i class="fa fa-plus"></i>
    <span id="price-no" class="price-no">เลือก</span>
    </span>
    <span class="loading">
    <img src="https://1112.com/images/spinner.svg">
    <span class="small">กำลังใส่สินค้าลงตะกร้า</span>
    </span>
    </button>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
  <!-- info section -->

  <section class="info_section layout_padding2">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-lg-3 info_col">
          <div class="info_contact">
            <h4>
              Address
            </h4>
            <div class="contact_link_box">
              <a href="">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Location
                </span>
              </a>
              <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call +01 1234567890
                </span>
              </a>
              <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                  demo@gmail.com
                </span>
              </a>
            </div>
          </div>
          <div class="info_social">
            <a href="">
              <i class="fa fa-facebook" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-twitter" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-linkedin" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-instagram" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-6 col-lg-3 info_col">
          <div class="info_detail">
            <h4>
              Info
            </h4>
            <p>
              necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful
            </p>
          </div>
        </div>
        <div class="col-md-6 col-lg-2 mx-auto info_col">
          <div class="info_link_box">
            <h4>
              Links
            </h4>
            <div class="info_links">
              <a class="active" href="index.php">
                Home
              </a>
              <a class="" href="Branch.php">
                Branch
              </a>
              <a class="" href="about.php">
                About
              </a>
              <a class="" href="service.php">
                Services
              </a>
              <a class="" href="Promotion.php">
                Promotion
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3 info_col ">
          <h4>
            Subscribe
          </h4>
          <form action="#">
            <input type="text" placeholder="Enter email" />
            <button type="submit">
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- end info section -->

  <!-- footer section -->
  <section class="footer_section">
    <div class="container">
      <p>
        &copy; <span id="displayYear"></span> All Rights Reserved By
        <a href="https://html.design/">Free Html Templates</a>
      </p>
    </div>
  </section>
  <!-- footer section -->

  <!-- jQery -->
  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <!-- popper js -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
  </script>
  <!-- bootstrap js -->
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <!-- owl slider -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <!-- custom js -->
  <script type="text/javascript" src="js/custom.js"></script>
  <!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap">
  </script>
  <!-- End Google Map -->

</body>

</html>