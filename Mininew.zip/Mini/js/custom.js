// to get current year
function getYear() {
    var currentDate = new Date();
    var currentYear = currentDate.getFullYear();
    document.querySelector("#displayYear").innerHTML = currentYear;
}

getYear();


// client section owl carousel
$(".client_owl-carousel").owlCarousel({
    loop: true,
    margin: 20,
    dots: false,
    nav: true,
    navText: [],
    autoplay: true,
    autoplayHoverPause: true,
    navText: [
        '<i class="fa fa-angle-left" aria-hidden="true"></i>',
        '<i class="fa fa-angle-right" aria-hidden="true"></i>'
    ],
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 2
        },
        1000: {
            items: 2
        }
    }
});



/** google_map js **/
function myMap() {
    var mapProp = {
        center: new google.maps.LatLng(40.712775, -74.005973),
        zoom: 18,
    };
    var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
}
document.getElementById('show-all-button').addEventListener('click', function() {
    // เมื่อคลิกปุ่ม "Show All", แสดงรายการทั้งหมด
    var allEvents = document.querySelectorAll('.event_outer');
    allEvents.forEach(function(event) {
        event.style.display = 'block';
    });
});
// หากคุณใช้ JavaScript เบื้องบน
document.getElementById('member-filter-button').addEventListener('click', function() {
    // เมื่อคลิกปุ่ม "Member", ซ่อนรายการทั้งหมด
    var allEvents = document.querySelectorAll('.event_outer');
    allEvents.forEach(function(event) {
        event.style.display = 'none';
    });

    // แสดงรายการที่มีคลาส "Member"
    var memberEvents = document.querySelectorAll('.Member');
    memberEvents.forEach(function(event) {
        event.style.display = 'block';
    });
});
document.getElementById('general-user-button').addEventListener('click', function() {
    // เมื่อคลิกปุ่ม "General user", ซ่อนรายการทั้งหมด
    var allEvents = document.querySelectorAll('.event_outer');
    allEvents.forEach(function(event) {
        event.style.display = 'none';
    });

    // แสดงรายการที่มีคลาส "General user"
    var generalUserEvents = document.querySelectorAll('.General.user');
    generalUserEvents.forEach(function(event) {
        event.style.display = 'block';
    });
});
document.getElementById('first-time-use-button').addEventListener('click', function() {
    // เมื่อคลิกปุ่ม "First time use", ซ่อนรายการทั้งหมด
    var allEvents = document.querySelectorAll('.event_outer');
    allEvents.forEach(function(event) {
        event.style.display = 'none';
    });

    // แสดงรายการที่มีคลาส "First time use"
    var firstTimeUseEvents = document.querySelectorAll('.First.time.use');
    firstTimeUseEvents.forEach(function(event) {
        event.style.display = 'block';
    });
});
// หากคุณใช้ JavaScript เบื้องบน
// หากคุณใช้ JavaScript เบื้องบน
document.getElementById('first-time-use-button').addEventListener('click', function() {
    var firstTimeUseEvents = document.querySelectorAll('.First.time.use');
    firstTimeUseEvents.forEach(function(event) {
        event.style.display = 'block';
        setTimeout(function() {
            event.style.opacity = 1;
            event.style.transform = 'scale(1)';
        }, 10); // รอเพื่อให้แสดงผลลูกเล่น
    });
});

document.getElementById('show-all-button').addEventListener('click', function() {
    var allEvents = document.querySelectorAll('.event_outer');
    allEvents.forEach(function(event) {
        event.style.display = 'block';
        setTimeout(function() {
            event.style.opacity = 1;
            event.style.transform = 'scale(1)';
        }, 10); // รอเพื่อให้แสดงผลลูกเล่น
    });
});

